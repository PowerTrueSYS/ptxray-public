# PTxray IBM i report bundle

The entry point is the report runner, not the one-file script:

    dist/tools/ibmi-scan.ksh --html --json --compliance cis-l1|cis-l2 --out DIR --monolith ./ptxray-ibmi.sh

Required inputs:

- `--monolith ./ptxray-ibmi.sh`
- `--compliance cis-l1` or `--compliance cis-l2`
- `--out DIR`: directory the runner writes

`--out` contains:

- `report.html`
- `report.json`
- `scan.ptx`
- `ptxray-ibmi.json` (Blueprint input)

The report and the Blueprint feed come from this runner; the one-file script alone does not produce them.
