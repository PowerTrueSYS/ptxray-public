# PTxray IBM i report bundle

The entry point is the report runner, not the one-file script:

    dist/tools/ibmi-scan.ksh --html --json --compliance cis-l1|cis-l2 --out DIR

This bundle includes `ptxray-defs.sh` at the top level; that is the adjacent downloader the runner's default definitions download uses.

Required inputs:

- `--compliance cis-l1` or `--compliance cis-l2`
- `--out DIR`: directory the runner writes

`--out` contains:

- `report.html`
- `report.json`
- `scan.ptx`
- `ptxray-ibmi.json` (Blueprint input)

The report and the Blueprint feed come from this runner; the one-file script alone does not produce them.

Fleet fan-out from an admin box (replaces `tools/ptxray-fleet.py`):

    dist/tools/ptxray-fleet.ksh --hosts FILE --platform ibmi --group G [--out DIR]

For each host in FILE: scp the tarball, run the chosen sub-runner remotely (key-only ssh, no passwords, read-only), and pull `--out` into `DIR/<host>/`. Per-host exit codes land in `DIR/fleet.tsv`. The wrapper never prints credentials.
