# PTxray IBM i report bundle

The entry point is the report runner, not the one-file script:

    mkdir -m 700 report
    ksh dist/tools/ibmi-scan.ksh --html --json --all --out report

This bundle includes `ptxray-defs.sh` at the top level; that is the adjacent downloader the runner's default definitions download uses.

Required inputs:

- `--out DIR`: an existing directory the runner writes

The default scope is the complete IBM i catalog, including Level 1, Level 2,
and operational checks. `--all` makes that selection explicit. Use
`--compliance cis-l1` or `--compliance cis-l2` for a specific compliance view;
both include operational checks. Running the command without arguments in a
terminal opens the menu, with the complete catalog selected by default.

The NetServer attribute reader uses an existing XMLSERVICE
`QXMLSERV.iPLUGR512K` installation. The scanner installs nothing and reports
unavailable evidence explicitly. Active SMTP and SMB network probes are
disabled; policies requiring that evidence remain not assessed. MFA and
malware coverage still require manual review. A complete catalog run is not
a claim of complete automated benchmark coverage.

`--out` contains:

- `report.html`
- `report.json`
- `scan.ptx`
- `ptxray-ibmi.json` (Blueprint input)

The report and the Blueprint feed come from this runner; the one-file script alone does not produce them.

Fleet fan-out from an admin box (replaces `tools/ptxray-fleet.py`):

    dist/tools/ptxray-fleet.ksh --hosts FILE --platform ibmi --group G [--out DIR]

For each host in FILE: scp the tarball, run the chosen sub-runner remotely (key-only ssh, no passwords, read-only), and pull `--out` into `DIR/<host>/`. Per-host exit codes land in `DIR/fleet.tsv`. The wrapper never prints credentials.
